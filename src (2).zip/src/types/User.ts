export interface User {
  id?: number;
  username: string;
  password: string;
  fullName: string;
  role: 'DOCTOR' | 'PATIENT';
}
