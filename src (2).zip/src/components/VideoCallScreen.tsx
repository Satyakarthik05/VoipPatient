import React, { useEffect, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Alert,
  Platform,
  PermissionsAndroid,
} from 'react-native';
import {
  RTCPeerConnection,
  RTCView,
  mediaDevices,
  MediaStream,
  RTCIceCandidate,
  RTCSessionDescription,
} from 'react-native-webrtc';
import InCallManager from 'react-native-incall-manager';

interface VideoCallScreenProps {
  route: {
    params: {
      currentUserId: string;
      otherUserId: string;
      isCaller: boolean;
      otherUserName?: string;
    };
  };
  navigation: any;
}

const VideoCallScreen: React.FC<VideoCallScreenProps> = ({
  route,
  navigation,
}) => {
  const { currentUserId, otherUserId, isCaller, otherUserName } = route.params;

  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [remoteStream, setRemoteStream] = useState<MediaStream | null>(null);
  const [status, setStatus] = useState(isCaller ? 'Calling...' : 'Connecting...');
  const [callConnected, setCallConnected] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isFrontCamera, setIsFrontCamera] = useState(true);
  const [isSpeakerOn, setIsSpeakerOn] = useState(true);

  const pc = useRef<RTCPeerConnection | null>(null);
  const ws = useRef<WebSocket | null>(null);

  const configuration = {
    iceServers: [{ urls: 'stun:stun.l.google.com:19302' }],
  };

  const setupWebSocket = () => {
    ws.current = new WebSocket('ws://192.168.0.103:8080/signal');

    ws.current.onopen = () => {
      ws.current?.send(JSON.stringify({ type: 'join', userId: currentUserId }));
      if (isCaller) {
        setupMedia();
      } else {
        ws.current?.send(
          JSON.stringify({
            type: 'call_accepted',
            from: currentUserId,
            to: otherUserId,
          }),
        );
        setupMedia();
      }
    };

    ws.current.onmessage = async message => {
      const data = JSON.parse(message.data);
      if (!pc.current) return;

      try {
        switch (data.type) {
          case 'offer':
            await pc.current.setRemoteDescription(new RTCSessionDescription(data.offer));
            const answer = await pc.current.createAnswer();
            await pc.current.setLocalDescription(answer);
            ws.current?.send(
              JSON.stringify({ type: 'answer', answer, target: otherUserId }),
            );
            setStatus('Connected');
            setCallConnected(true);
            break;

          case 'answer':
            await pc.current.setRemoteDescription(new RTCSessionDescription(data.answer));
            setStatus('Connected');
            setCallConnected(true);
            break;

          case 'candidate':
            await pc.current.addIceCandidate(new RTCIceCandidate(data.candidate));
            break;
        }
      } catch (error) {
        console.error('WebRTC signaling error:', error);
      }
    };

    ws.current.onerror = () => {
      Alert.alert('Connection Error', 'Failed to connect to signaling server');
      navigation.goBack();
    };
  };

  const setupMedia = async (cameraType: 'front' | 'back' = 'front') => {
    try {
      if (Platform.OS === 'android') {
        const granted = await PermissionsAndroid.requestMultiple([
          PermissionsAndroid.PERMISSIONS.CAMERA,
          PermissionsAndroid.PERMISSIONS.RECORD_AUDIO,
        ]);

        if (
          granted['android.permission.CAMERA'] !== PermissionsAndroid.RESULTS.GRANTED ||
          granted['android.permission.RECORD_AUDIO'] !== PermissionsAndroid.RESULTS.GRANTED
        ) {
          Alert.alert('Permissions Required', 'Camera and Microphone access is needed');
          return;
        }
      }

      const stream = await mediaDevices.getUserMedia({
        video: {
          facingMode: cameraType === 'front' ? 'user' : 'environment',
          width: 640,
          height: 480,
          frameRate: 30,
        },
        audio: true,
      });

      const videoTrack = stream.getVideoTracks()[0];
      const audioTrack = stream.getAudioTracks()[0];

      // Replace track if peer connection is already active
      if (pc.current) {
        const senders = pc.current.getSenders();

        senders.forEach(sender => {
          if (sender.track?.kind === 'video' && videoTrack) {
            sender.replaceTrack(videoTrack);
          } else if (sender.track?.kind === 'audio' && audioTrack) {
            sender.replaceTrack(audioTrack);
          }
        });

        // Only add tracks if not already present (first-time setup)
        if (senders.length === 0) {
          stream.getTracks().forEach(track => {
            pc.current?.addTrack(track, stream);
          });
        }
      } else {
        pc.current = new RTCPeerConnection(configuration);

        stream.getTracks().forEach(track => {
          pc.current?.addTrack(track, stream);
        });

        (pc.current as any).onicecandidate = (event: any) => {
          if (event.candidate) {
            ws.current?.send(
              JSON.stringify({
                type: 'candidate',
                candidate: event.candidate,
                target: otherUserId,
              }),
            );
          }
        };

        (pc.current as any).ontrack = (event: any) => {
          if (event.streams && event.streams.length > 0) {
            const remote = event.streams[0];
            setRemoteStream(remote);
            setStatus('Connected');
            InCallManager.start({ media: 'audio' });
            InCallManager.setSpeakerphoneOn(true);
          }
        };
      }

      setLocalStream(stream);

      if (isCaller && !callConnected && pc.current) {
        const offer = await pc.current.createOffer({});
        await pc.current.setLocalDescription(offer);
        ws.current?.send(
          JSON.stringify({
            type: 'offer',
            offer,
            target: otherUserId,
          }),
        );
      }
    } catch (error) {
      console.error('Media setup error:', error);
      Alert.alert('Media Error', 'Could not access camera or microphone');
      navigation.goBack();
    }
  };

  const toggleMute = () => {
    if (localStream) {
      const audioTracks = localStream.getAudioTracks();
      if (audioTracks.length > 0) {
        audioTracks[0].enabled = !audioTracks[0].enabled;
        setIsMuted(!audioTracks[0].enabled);
      }
    }
  };

  const toggleSpeaker = () => {
    setIsSpeakerOn(prev => {
      const newState = !prev;
      InCallManager.setSpeakerphoneOn(newState);
      return newState;
    });
  };

  const switchCamera = () => {
    const newCameraType = isFrontCamera ? 'back' : 'front';
    setIsFrontCamera(!isFrontCamera);
    setupMedia(newCameraType); // This now uses replaceTrack()
  };

  const endCall = () => {
    pc.current?.close();
    ws.current?.close();
    localStream?.getTracks().forEach(track => track.stop());
    InCallManager.stop();
    navigation.goBack();
  };

  useEffect(() => {
    setupWebSocket();
    return () => {
      endCall();
    };
  }, []);

  return (
    <View style={styles.container}>
      {remoteStream ? (
        <RTCView
          streamURL={remoteStream.toURL()}
          style={styles.remoteVideo}
          objectFit="cover"
        />
      ) : (
        <View style={styles.remoteVideoPlaceholder}>
          <Text style={styles.statusText}>
            {status} {otherUserName ? `with ${otherUserName}` : ''}
          </Text>
        </View>
      )}

      {localStream && (
        <RTCView
          streamURL={localStream.toURL()}
          style={styles.localVideo}
          objectFit="cover"
          mirror={isFrontCamera}
          zOrder={1}
        />
      )}

      <View style={styles.controlsContainer}>
        <TouchableOpacity onPress={toggleMute} style={styles.controlButton}>
          <Text style={styles.controlButtonEmoji}>{isMuted ? '🔇' : '🎤'}</Text>
          <Text style={styles.controlButtonText}>{isMuted ? 'Unmute' : 'Mute'}</Text>
        </TouchableOpacity>

        <TouchableOpacity onPress={toggleSpeaker} style={styles.controlButton}>
          <Text style={styles.controlButtonEmoji}>{isSpeakerOn ? '🔊' : '🎧'}</Text>
          <Text style={styles.controlButtonText}>{isSpeakerOn ? 'Speaker' : 'Earpiece'}</Text>
        </TouchableOpacity>

        <TouchableOpacity onPress={switchCamera} style={styles.controlButton}>
          <Text style={styles.controlButtonEmoji}>🔄</Text>
          <Text style={styles.controlButtonText}>Switch</Text>
        </TouchableOpacity>

        <TouchableOpacity onPress={endCall} style={styles.endCallButton}>
          <Text style={styles.controlButtonEmoji}>📞</Text>
          <Text style={styles.endCallButtonText}>End</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000' },
  remoteVideo: { flex: 1, backgroundColor: '#000' },
  remoteVideoPlaceholder: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#000',
  },
  localVideo: {
    position: 'absolute',
    width: 120,
    height: 160,
    top: 20,
    right: 20,
    borderRadius: 8,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: '#fff',
  },
  statusText: { color: 'white', fontSize: 18 },
  controlsContainer: {
    position: 'absolute',
    bottom: 40,
    left: 0,
    right: 0,
    flexDirection: 'row',
    justifyContent: 'space-evenly',
    alignItems: 'center',
  },
  controlButton: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    width: 70,
    height: 70,
    borderRadius: 35,
  },
  controlButtonEmoji: { fontSize: 24 },
  controlButtonText: {
    color: 'white',
    fontSize: 12,
    marginTop: 4,
  },
  endCallButton: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'red',
    width: 70,
    height: 70,
    borderRadius: 35,
  },
  endCallButtonText: {
    color: 'white',
    fontSize: 12,
    marginTop: 4,
  },
});

export default VideoCallScreen;
