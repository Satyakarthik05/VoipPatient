import React, { useState } from 'react';
import { View, TextInput, Button, Text, StyleSheet, Alert } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { User } from '../types/User'

type Props = NativeStackScreenProps<any, 'Login'>;

const LoginScreen: React.FC<Props> = ({ navigation }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = async () => {
    try {
      // Simple GET request (Spring Security handles actual auth)
      const res = await fetch('http://192.168.0.103:8080/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({username,password}),
      });

      if (res.ok) {
        const userRes = await fetch(`http://192.168.0.103:8080/api/users/role-view?role=DOCTOR`);
        const userRole = username.toLowerCase().includes('doctor') ? 'DOCTOR' : 'PATIENT';
        const userdetails= await res.json();
        Alert.alert('Login successful', `Welcome ${userdetails.fullName}`);

        const userdirectrole = userdetails.role;

        navigation.navigate('Home', {
          username,
          role: userdirectrole,
          id: userdetails.id,
        });
      } else {
        Alert.alert('Login failed', 'Invalid credentials');
      }
    } catch (err) {
      console.error(err);
      Alert.alert('Error', 'Something went wrong');
    }
  };

  return (
    <View style={styles.container}>
      <TextInput placeholder="Username" onChangeText={setUsername} style={styles.input} />
      <TextInput placeholder="Password" secureTextEntry onChangeText={setPassword} style={styles.input} />
      <Button title="Login" onPress={handleLogin} />
      <Text onPress={() => navigation.navigate('Register')} style={styles.link}>
        Don't have an account? Register
      </Text>
    </View>
  );
};

export default LoginScreen;

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', padding: 20 },
  input: { borderBottomWidth: 1, marginBottom: 20 },
  link: { marginTop: 20, color: 'blue', textAlign: 'center' },
});
