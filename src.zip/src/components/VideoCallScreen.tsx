import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  PermissionsAndroid,
  Platform,
} from 'react-native';
import {
  RTCPeerConnection,
  RTCView,
  mediaDevices,
  MediaStream,
  RTCIceCandidate,
  RTCSessionDescription,
} from 'react-native-webrtc';
import io from 'socket.io-client';
import { check, request, PERMISSIONS, RESULTS } from 'react-native-permissions';

type CallProps = {
  onEndCall: () => void;
  otherUserId: string;
  isCaller: boolean;
};

const VideoCallScreen: React.FC<CallProps> = ({ onEndCall, otherUserId, isCaller }) => {
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [remoteStream, setRemoteStream] = useState<MediaStream | null>(null);
  const [cameraType, setCameraType] = useState<'front' | 'back'>('front');
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOn, setIsVideoOn] = useState(true);
  const [callStatus, setCallStatus] = useState('Connecting...');
  
  const peerConnection = useRef<RTCPeerConnection | null>(null);
  const socket = useRef<any>(null);
  const configuration = {
    iceServers: [
      { urls: 'stun:stun.l.google.com:19302' },
      { urls: 'stun:stun1.l.google.com:19302' },
      { urls: 'stun:stun2.l.google.com:19302' },
    ],
  };

  // Initialize WebRTC and signaling
  useEffect(() => {
    const init = async () => {
      await requestPermissions();
      await setupWebRTC();
      setupSignaling();
    };

    init();

    return () => {
      if (peerConnection.current) {
        peerConnection.current.close();
      }
      if (localStream) {
        localStream.getTracks().forEach(track => track.stop());
      }
      if (socket.current) {
        socket.current.disconnect();
      }
    };
  }, []);

  const requestPermissions = async () => {
    if (Platform.OS === 'android') {
      try {
        const grants = await PermissionsAndroid.requestMultiple([
          PermissionsAndroid.PERMISSIONS.CAMERA,
          PermissionsAndroid.PERMISSIONS.RECORD_AUDIO,
        ]);

        if (
          grants['android.permission.CAMERA'] !== PermissionsAndroid.RESULTS.GRANTED ||
          grants['android.permission.RECORD_AUDIO'] !== PermissionsAndroid.RESULTS.GRANTED
        ) {
          console.log('Permissions not granted');
          return false;
        }
        return true;
      } catch (err) {
        console.warn(err);
        return false;
      }
    } else {
      const cameraPermission = await check(PERMISSIONS.IOS.CAMERA);
      const micPermission = await check(PERMISSIONS.IOS.MICROPHONE);

      if (cameraPermission !== RESULTS.GRANTED) {
        await request(PERMISSIONS.IOS.CAMERA);
      }
      if (micPermission !== RESULTS.GRANTED) {
        await request(PERMISSIONS.IOS.MICROPHONE);
      }
      return true;
    }
  };

  const setupSignaling = () => {
    socket.current = io('http://192.168.0.5:8080', {
      transports: ['websocket'],
    });

    socket.current.on('connect', () => {
      console.log('Connected to signaling server');
      socket.current.emit('join', { userId: 'current-user-id', otherUserId });
    });

    socket.current.on('offer', async (offer: RTCSessionDescription) => {
      if (!isCaller) {
        await handleOffer(offer);
      }
    });

    socket.current.on('answer', async (answer: RTCSessionDescription) => {
      if (isCaller) {
        await handleAnswer(answer);
      }
    });

    socket.current.on('candidate', async (candidate: RTCIceCandidate) => {
      await handleICECandidate(candidate);
    });

    socket.current.on('disconnect', () => {
      setCallStatus('Disconnected');
      onEndCall();
    });
  };

  const setupWebRTC = async () => {
    try {
      // Get local stream
      const stream = await mediaDevices.getUserMedia({
        audio: true,
        video: {
          facingMode: cameraType,
          width: { min: 640, ideal: 1280 },
          height: { min: 480, ideal: 720 },
          frameRate: { min: 30, ideal: 60 },
        },
      });
      setLocalStream(stream);

      // Create peer connection
      peerConnection.current = new RTCPeerConnection(configuration);

      // Add tracks
      stream.getTracks().forEach(track => {
        peerConnection.current?.addTrack(track, stream);
      });

      // Set up event handlers
      (peerConnection.current as any).onicecandidate = (event:any) => {
        if (event.candidate) {
          socket.current.emit('candidate', {
            candidate: event.candidate,
            otherUserId,
          });
        }
      };

      (peerConnection.current as any).ontrack = (event:any) => {
        if (event.streams && event.streams[0]) {
          setRemoteStream(event.streams[0]);
          setCallStatus('Connected');
        }
      };

      (peerConnection.current as any).oniceconnectionstatechange = () => {
        if (peerConnection.current?.iceConnectionState === 'disconnected') {
          setCallStatus('Disconnected');
          onEndCall();
        }
      };

      if (isCaller) {
        createOffer();
      }
    } catch (err) {
      console.error('WebRTC setup error:', err);
      setCallStatus('Connection failed');
    }
  };

  const createOffer = async () => {
    try {
      const offer = await peerConnection.current?.createOffer({});
      await peerConnection.current?.setLocalDescription(offer);
      socket.current.emit('offer', {
        offer,
        otherUserId,
      });
    } catch (err) {
      console.error('Error creating offer:', err);
    }
  };

  const handleOffer = async (offer: RTCSessionDescription) => {
    try {
      await peerConnection.current?.setRemoteDescription(offer);
      const answer = await peerConnection.current?.createAnswer();
      await peerConnection.current?.setLocalDescription(answer);
      socket.current.emit('answer', {
        answer,
        otherUserId,
      });
    } catch (err) {
      console.error('Error handling offer:', err);
    }
  };

  const handleAnswer = async (answer: RTCSessionDescription) => {
    try {
      await peerConnection.current?.setRemoteDescription(answer);
    } catch (err) {
      console.error('Error handling answer:', err);
    }
  };

  const handleICECandidate = async (candidate: RTCIceCandidate) => {
    try {
      await peerConnection.current?.addIceCandidate(candidate);
    } catch (err) {
      console.error('Error adding ICE candidate:', err);
    }
  };

  const toggleMute = () => {
    if (localStream) {
      localStream.getAudioTracks().forEach(track => {
        track.enabled = !track.enabled;
      });
      setIsMuted(!isMuted);
    }
  };

  const toggleVideo = () => {
    if (localStream) {
      localStream.getVideoTracks().forEach(track => {
        track.enabled = !track.enabled;
      });
      setIsVideoOn(!isVideoOn);
    }
  };

  const switchCamera = async () => {
    const newCameraType = cameraType === 'front' ? 'back' : 'front';
    setCameraType(newCameraType);
    
    if (localStream) {
      localStream.getVideoTracks().forEach(track => track.stop());
      
      const newStream = await mediaDevices.getUserMedia({
        video: {
          facingMode: newCameraType,
          width: { min: 640, ideal: 1280 },
          height: { min: 480, ideal: 720 },
          frameRate: { min: 30, ideal: 60 },
        },
        audio: true,
      });
      
      setLocalStream(newStream);
      
      // Replace the video track in the peer connection
      const videoTrack = newStream.getVideoTracks()[0];
      const sender = peerConnection.current?.getSenders().find(
        s => s.track?.kind === 'video'
      );
      if (sender) {
        sender.replaceTrack(videoTrack);
      }
    }
  };

  const endCall = () => {
    if (peerConnection.current) {
      peerConnection.current.close();
    }
    if (localStream) {
      localStream.getTracks().forEach(track => track.stop());
    }
    if (socket.current) {
      socket.current.disconnect();
    }
    onEndCall();
  };

  return (
    <View style={styles.container}>
      {remoteStream ? (
        <RTCView
          streamURL={remoteStream.toURL()}
          style={styles.remoteVideo}
          objectFit="cover"
          mirror={false}
        />
      ) : (
        <View style={styles.remoteVideoPlaceholder}>
          <Text style={styles.placeholderText}>Connecting to {otherUserId}...</Text>
        </View>
      )}

      {localStream && (
        <RTCView
          streamURL={localStream.toURL()}
          style={styles.localVideo}
          objectFit="cover"
          mirror={cameraType === 'front'}
        />
      )}

      <View style={styles.callStatusContainer}>
        <Text style={styles.callStatusText}>{callStatus}</Text>
      </View>

      <View style={styles.controlsContainer}>
        <TouchableOpacity style={styles.controlButton} onPress={toggleMute}>
          <Text style={styles.controlButtonText}>
            {isMuted ? 'Unmute' : 'Mute'}
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.controlButton, styles.endCallButton]}
          onPress={endCall}
        >
          <Text style={styles.endCallButtonText}>End Call</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.controlButton} onPress={toggleVideo}>
          <Text style={styles.controlButtonText}>
            {isVideoOn ? 'Video Off' : 'Video On'}
          </Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.controlButton} onPress={switchCamera}>
          <Text style={styles.controlButtonText}>Switch Camera</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  remoteVideo: {
    flex: 1,
    backgroundColor: '#000',
  },
  remoteVideoPlaceholder: {
    flex: 1,
    backgroundColor: '#222',
    justifyContent: 'center',
    alignItems: 'center',
  },
  placeholderText: {
    color: '#fff',
    fontSize: 18,
  },
  localVideo: {
    position: 'absolute',
    width: 100,
    height: 150,
    top: 20,
    right: 20,
    borderRadius: 8,
    overflow: 'hidden',
  },
  controlsContainer: {
    position: 'absolute',
    bottom: 40,
    left: 0,
    right: 0,
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
  },
  controlButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    padding: 15,
    borderRadius: 50,
    width: 70,
    height: 70,
    justifyContent: 'center',
    alignItems: 'center',
  },
  controlButtonText: {
    color: '#fff',
    fontSize: 12,
    textAlign: 'center',
  },
  endCallButton: {
    backgroundColor: 'red',
    width: 80,
    height: 80,
  },
  endCallButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: 'bold',
  },
  callStatusContainer: {
    position: 'absolute',
    top: 50,
    left: 0,
    right: 0,
    alignItems: 'center',
  },
  callStatusText: {
    color: '#fff',
    fontSize: 16,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    padding: 10,
    borderRadius: 20,
  },
});

export default VideoCallScreen;